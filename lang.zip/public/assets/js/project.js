$(document).ready( function () {
    $('#btn').on('click', function (e) {
        alert($(this).data("value"));
    });
} );